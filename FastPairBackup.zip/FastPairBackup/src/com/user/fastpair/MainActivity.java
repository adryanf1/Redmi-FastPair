package com.user.fastpair;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        View container = findViewById(R.id.main_container);
        if (container != null) {
            container.setAlpha(0f);
            container.setTranslationY(50f);
            container.animate().alpha(1f).translationY(0f).setDuration(500).start();
        }

        prefs = getSharedPreferences("Configuracion", Context.MODE_PRIVATE);
        final EditText etNombre = (EditText) findViewById(R.id.et_nombre);
        etNombre.setText(prefs.getString("nombre_audifonos", "Redmi"));

        findViewById(R.id.btn_negro).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().putString("color", "negro").putString("nombre_audifonos", etNombre.getText().toString()).apply();
                Toast.makeText(MainActivity.this, "Color: Negro", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btn_celeste).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().putString("color", "celeste").putString("nombre_audifonos", etNombre.getText().toString()).apply();
                Toast.makeText(MainActivity.this, "Color: Celeste", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btn_3s).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { prefs.edit().putInt("tiempo", 3000).apply(); Toast.makeText(MainActivity.this, "Duración: 3s", Toast.LENGTH_SHORT).show(); }
        });
        findViewById(R.id.btn_5s).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { prefs.edit().putInt("tiempo", 5000).apply(); Toast.makeText(MainActivity.this, "Duración: 5s", Toast.LENGTH_SHORT).show(); }
        });
        findViewById(R.id.btn_10s).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { prefs.edit().putInt("tiempo", 10000).apply(); Toast.makeText(MainActivity.this, "Duración: 10s", Toast.LENGTH_SHORT).show(); }
        });

        findViewById(R.id.btn_bateria).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "App ya protegida", Toast.LENGTH_SHORT).show();
                }
            }
        });

        findViewById(R.id.btn_test).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().putString("nombre_audifonos", etNombre.getText().toString()).apply();
                Intent i = new Intent(MainActivity.this, BtleReceiver.class);
                i.setAction("com.user.fastpair.TEST_POPUP");
                sendBroadcast(i);
            }
        });
    }
}
