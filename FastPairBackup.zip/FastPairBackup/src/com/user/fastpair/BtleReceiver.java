package com.user.fastpair;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class BtleReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("Configuracion", Context.MODE_PRIVATE);
        int tiempoDuracion = prefs.getInt("tiempo", 6000);

        if ("com.user.fastpair.TEST_POPUP".equals(intent.getAction())) {
            showPopup(context, prefs.getString("color", "negro"), prefs.getString("nombre_audifonos", "Mis Audífonos (Prueba)"), tiempoDuracion);
            return;
        }

        if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(intent.getAction())) {
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (device == null) return;

            String nombreBuscado = prefs.getString("nombre_audifonos", "redmi").toLowerCase();
            String nombreReal = null;

            if (context.checkSelfPermission("android.permission.BLUETOOTH_CONNECT") == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        java.lang.reflect.Method method = device.getClass().getMethod("getAlias");
                        nombreReal = (String) method.invoke(device);
                    } catch (Exception e) {}
                }
                if (nombreReal == null || nombreReal.isEmpty()) nombreReal = device.getName(); 
            }

            if (nombreReal != null && nombreReal.toLowerCase().contains(nombreBuscado)) {
                showPopup(context, prefs.getString("color", "negro"), nombreReal, tiempoDuracion);
            }
        }
    }

    private void showPopup(final Context context, String color, String nombreDispositivo, int tiempo) {
        final WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.TRANSLUCENT);

        p.gravity = Gravity.BOTTOM; p.dimAmount = 0.4f;
        p.windowAnimations = android.R.style.Animation_InputMethod;

        LayoutInflater inflater = LayoutInflater.from(context);
        final View view = inflater.inflate(R.layout.popup, null);

        ImageView img = (ImageView) view.findViewById(R.id.img_audifonos);
        int resId = context.getResources().getIdentifier(color, "drawable", context.getPackageName());
        if (resId != 0) img.setImageResource(resId);

        TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
        if (tvTitle != null && nombreDispositivo != null) tvTitle.setText(nombreDispositivo);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                try { wm.removeView(view); } catch (Exception e) {}
            }
        });

        view.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { try { wm.removeView(view); } catch (Exception e) {} }
        });

        wm.addView(view, p);
        
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() { try { if (view.isAttachedToWindow()) wm.removeView(view); } catch (Exception e) {} }
        }, tiempo);
    }
}
