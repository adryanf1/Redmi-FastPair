#!/bin/bash
set -e # Detiene el script inmediatamente si hay un error

export ANDROID_JAR="$HOME/FastPairTest/android.jar"

if [ ! -f "$ANDROID_JAR" ]; then
    echo "❌ Error: android.jar no encontrado. Descárgalo primero."
    exit 1
fi

echo "🧹 Limpiando compilaciones anteriores..."
rm -rf obj/* dex/* app.apk.unaligned app.apk compiled_res.zip 2>/dev/null || true

echo "📦 1. Compilando recursos (AAPT2 Compile)..."
aapt2 compile --dir res -o compiled_res.zip

echo "🔗 2. Enlazando recursos y generando R.java (AAPT2 Link)..."
aapt2 link compiled_res.zip -I $ANDROID_JAR --manifest AndroidManifest.xml --java src -o app.apk.unaligned

ecj -d obj -classpath $ANDROID_JAR -sourcepath src src/com/user/fastpair/*.java


echo "⚙️  4. Convirtiendo a bytecode (D8)..."
d8 --output dex obj/com/user/fastpair/*.class

echo "🗂️  5. Añadiendo código Dex al APK..."
cd dex
zip -q ../app.apk.unaligned classes.dex
cd ..

echo "🔑 6. Firmando el APK (Apksigner)..."
if [ ! -f debug.keystore ]; then
    keytool -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
fi
apksigner sign --ks debug.keystore --ks-pass pass:android --key-pass pass:android --out app.apk app.apk.unaligned

echo "✅ ¡COMPILACIÓN EXITOSA CON AAPT2!"
cp app.apk ~/storage/downloads/FastPairMaterial.apk
echo "📁 Tu app Material You ha sido copiada a Descargas como 'FastPairMaterial.apk'"

